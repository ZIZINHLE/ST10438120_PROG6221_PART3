﻿using System;
using System.Collections.Generic;
using System.Windows;

namespace CybersecurityAwarenessBotWPF
{
    public partial class TaskWindow : Window
    {
        private List<string> log;

        public TaskWindow(List<string> sharedLog)
        {
            InitializeComponent();
            log = sharedLog;
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            string task = txtTask.Text.Trim();
            if (string.IsNullOrWhiteSpace(task)) return;

            string date = dateReminder.SelectedDate?.ToShortDateString() ?? "unspecified date";
            log.Add($"{DateTime.Now:T} - Task added: '{task}' (Reminder set for {date})");

            MessageBox.Show("Task added successfully!", "Success");
            this.Close();
        }
    }
}
