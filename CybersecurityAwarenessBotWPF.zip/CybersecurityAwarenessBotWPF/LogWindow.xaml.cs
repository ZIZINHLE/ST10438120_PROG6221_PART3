﻿using System.Collections.Generic;
using System.Windows;

namespace CybersecurityAwarenessBotWPF
{
    public partial class LogWindow : Window
    {
        public LogWindow(List<string> log)
        {
            InitializeComponent();
            lstLog.ItemsSource = log;
        }
    }
}
