﻿using System;
using System.Collections.Generic;
using System.Windows;

namespace CybersecurityAwarenessBotWPF
{
    public partial class QuizWindow : Window
    {
        private List<string> log;
        private int current = 0, score = 0;

        private List<(string Question, string[] Options, string Answer)> questions = new()
        {
            ("What is phishing?", new[] { "Fishing on the internet", "Scam emails", "Safe email practice" }, "Scam emails"),
            ("What should you do with suspicious emails?", new[] { "Report as phishing", "Reply politely", "Ignore them" }, "Report as phishing"),
            ("What is 2FA?", new[] { "Two-Factor Authentication", "Two-Faced Account", "Fast Access" }, "Two-Factor Authentication"),
            ("True or False: Your name is a strong password.", new[] { "True", "False" }, "False"),
            ("Which is safer?", new[] { "123456", "Pa$$w0rd!", "qwerty" }, "Pa$$w0rd!"),
            ("Why review app permissions?", new[] { "To free space", "To reduce risk", "To get updates" }, "To reduce risk"),
            ("What is a firewall?", new[] { "Wall of fire", "Network filter", "Game cheat" }, "Network filter"),
            ("Public Wi-Fi is safe without VPN.", new[] { "True", "False" }, "False"),
            ("What’s a good backup method?", new[] { "USB only", "Cloud + USB", "None" }, "Cloud + USB"),
            ("What is social engineering?", new[] { "Designing websites", "Tricking people", "Building apps" }, "Tricking people"),
        };

        public QuizWindow(List<string> sharedLog)
        {
            InitializeComponent();
            log = sharedLog;
            LoadQuestion();
        }

        private void LoadQuestion()
        {
            if (current >= questions.Count)
            {
                MessageBox.Show($"Quiz complete! You scored {score}/10\n" +
                    (score >= 8 ? "Great job! You're a cybersecurity pro!" : "Keep learning to stay safe!"));
                log.Add($"{DateTime.Now:T} - Quiz completed. Score: {score}/10");
                this.Close();
                return;
            }

            txtQuestion.Text = $"Q{current + 1}: {questions[current].Question}";
            lstOptions.ItemsSource = questions[current].Options;
        }

        private void btnSubmit_Click(object sender, RoutedEventArgs e)
        {
            if (lstOptions.SelectedItem == null) return;

            string selected = lstOptions.SelectedItem.ToString();
            if (selected == questions[current].Answer)
            {
                score++;
                MessageBox.Show("Correct!", "Feedback");
            }
            else
            {
                MessageBox.Show($"Incorrect. Answer: {questions[current].Answer}", "Feedback");
            }

            current++;
            LoadQuestion();
        }
    }
}
