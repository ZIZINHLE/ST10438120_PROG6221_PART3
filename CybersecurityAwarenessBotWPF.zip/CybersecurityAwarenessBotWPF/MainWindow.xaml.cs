﻿using System;
using System.Collections.Generic;
using System.Windows;

namespace CybersecurityAwarenessBotWPF
{
    public partial class MainWindow : Window
    {
        private List<string> activityLog = new();
        private Dictionary<string, string> keywordResponses = new()
        {
            { "password", "Use strong, unique passwords and avoid personal details." },
            { "scam", "Never share personal info with untrusted sources." },
            { "privacy", "Review your settings regularly to protect your privacy." },
            { "2fa", "Two-factor authentication adds an extra layer of security to your accounts." }
        };

        private List<string> phishingTips = new()
        {
            "Be cautious of emails asking for info.",
            "Check sender addresses carefully.",
            "Avoid unknown links or attachments.",
            "Watch for spelling errors in emails."
        };

        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnSend_Click(object sender, RoutedEventArgs e)
        {
            string userInput = txtUserInput.Text.Trim();
            if (string.IsNullOrWhiteSpace(userInput)) return;

            AddToChat($"👤 You: {userInput}");
            txtUserInput.Clear();
            string response = GetBotResponse(userInput.ToLower());
            AddToChat($"🤖 Bot: {response}");
        }

        private string GetBotResponse(string input)
        {
            if (input.Contains("activity log") || input.Contains("what have you done"))
                return GetActivitySummary();

            if (input.Contains("remind") || input.Contains("set reminder") || input.Contains("add task"))
            {
                var taskWin = new TaskWindow(activityLog);
                taskWin.ShowDialog();
                return "Task Assistant opened. Let’s stay secure!";
            }

            if (input.Contains("start quiz") || input.Contains("cybersecurity quiz"))
            {
                var quizWin = new QuizWindow(activityLog);
                quizWin.ShowDialog();
                return "Quiz launched!";
            }

            if (input.Contains("phishing"))
            {
                string tip = phishingTips[new Random().Next(phishingTips.Count)];
                AddToLog("Phishing tip shared.");
                return tip;
            }

            foreach (var key in keywordResponses.Keys)
            {
                if (input.Contains(key))
                {
                    AddToLog($"Info on {key} shared.");
                    return keywordResponses[key];
                }
            }

            return "Sorry, I didn’t quite catch that. Try rephrasing!";
        }

        private void AddToChat(string msg)
        {
            lstChat.Items.Add(msg);
        }

        private void AddToLog(string entry)
        {
            if (activityLog.Count >= 10)
                activityLog.RemoveAt(0);
            activityLog.Add($"{DateTime.Now:T} - {entry}");
        }

        private string GetActivitySummary()
        {
            if (activityLog.Count == 0) return "No recent actions yet.";
            return "Recent Actions:\n" + string.Join("\n", activityLog);
        }

        private void btnTask_Click(object sender, RoutedEventArgs e)
        {
            var taskWindow = new TaskWindow(activityLog);
            taskWindow.ShowDialog();
        }

        private void btnQuiz_Click(object sender, RoutedEventArgs e)
        {
            var quizWindow = new QuizWindow(activityLog);
            quizWindow.ShowDialog();
        }

        private void btnLog_Click(object sender, RoutedEventArgs e)
        {
            var logWindow = new LogWindow(activityLog);
            logWindow.ShowDialog();
        }
    }
}
